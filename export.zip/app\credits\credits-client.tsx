"use client";

import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Lock, CheckCircle, ArrowRight, Zap } from "lucide-react";
import Link from "next/link";

type Credit = {
  vendor: string;
  name: string;
  value: string;
  category: string;
  eligibility: string[];
  public_description: string;
  locked_instructions: string;
};

function FadeIn({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}>
      {children}
    </motion.div>
  );
}

const STAGES = ["Bootstrapped", "Funded", "Accelerator"];

export default function CreditsClient({ credits }: { credits: Credit[] }) {
  const [selectedStage, setSelectedStage] = useState<string | null>(null);

  const eligible = selectedStage
    ? credits.filter((c) => c.eligibility.includes(selectedStage))
    : credits;

  const totalValue = eligible.reduce((sum, c) => {
    const num = parseInt(c.value.replace(/[^0-9]/g, ""));
    return sum + (isNaN(num) ? 0 : num);
  }, 0);

  const formatTotal = (n: number) =>
    n >= 1000000 ? `$${(n / 1000000).toFixed(2)}M+` : `$${(n / 1000).toFixed(0)}K+`;

  return (
    <div style={{ background: "#fafafa", minHeight: "100vh", fontFamily: "Inter, sans-serif" }}>

      {/* Nav */}
      <nav className="sticky top-0 z-50" style={{ borderBottom: "1px solid #e4e4e7", background: "rgba(250,250,250,0.9)", backdropFilter: "blur(12px)" }}>
        <div className="max-w-6xl mx-auto px-8 h-14 flex items-center justify-between">
          <Link href="/" style={{ textDecoration: "none" }}>
            <span style={{ color: "#09090b", fontWeight: 600, fontSize: "0.95rem", letterSpacing: "0.12em" }}>FOUNDER OS</span>
          </Link>
          <div className="flex items-center gap-6">
            <Link href="/directory" style={{ color: "#71717a", fontSize: "0.875rem", textDecoration: "none" }}>Directory</Link>
            <span style={{ color: "#09090b", fontSize: "0.875rem", fontWeight: 500 }}>Credits</span>
          </div>
        </div>
      </nav>

      {/* Header */}
      <div style={{ borderBottom: "1px solid #e4e4e7", background: "#fff", padding: "48px 0 36px" }}>
        <div className="max-w-6xl mx-auto px-8">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}>
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "10px" }}>Premium · One-time $149</p>
            <h1 style={{ fontSize: "clamp(1.6rem, 3vw, 2.4rem)", fontWeight: 600, letterSpacing: "-0.02em", color: "#09090b", marginBottom: "8px" }}>
              Startup Credits
            </h1>
            <p style={{ color: "#a1a1aa", fontSize: "0.9rem", marginBottom: "28px" }}>
              Select your startup stage to see which credits you qualify for.
            </p>

            {/* Stage selector */}
            <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "20px" }}>
              {STAGES.map((stage) => (
                <button
                  key={stage}
                  onClick={() => setSelectedStage(selectedStage === stage ? null : stage)}
                  style={{
                    padding: "8px 20px", borderRadius: "999px", fontSize: "0.825rem", cursor: "pointer", fontWeight: 400, border: "1px solid",
                    borderColor: selectedStage === stage ? "#09090b" : "#e4e4e7",
                    background: selectedStage === stage ? "#09090b" : "#fff",
                    color: selectedStage === stage ? "#fff" : "#71717a",
                    transition: "all 0.15s",
                  }}
                >
                  {stage}
                </button>
              ))}
            </div>

            {/* Eligible total */}
            {selectedStage && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                style={{ display: "inline-flex", alignItems: "center", gap: "10px", background: "#fafafa", border: "1px solid #e4e4e7", borderRadius: "10px", padding: "10px 18px" }}
              >
                <CheckCircle style={{ width: "14px", height: "14px", color: "#16a34a" }} />
                <span style={{ fontSize: "0.85rem", color: "#09090b" }}>
                  As a <strong>{selectedStage}</strong> startup, you qualify for{" "}
                  <strong style={{ color: "#dc2626" }}>{formatTotal(totalValue)}</strong> in credits
                </span>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>

      {/* Credits grid */}
      <div className="max-w-6xl mx-auto px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {eligible.map((credit, i) => (
            <FadeIn key={credit.vendor} delay={i * 0.08}>
              <div style={{ background: "#fff", border: "1px solid #e4e4e7", borderRadius: "12px", overflow: "hidden" }}>
                {/* Card header */}
                <div style={{ padding: "20px 24px", borderBottom: "1px solid #e4e4e7", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div>
                    <div style={{ fontSize: "0.65rem", color: "#a1a1aa", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "4px" }}>{credit.category}</div>
                    <div style={{ fontSize: "1rem", fontWeight: 600, color: "#09090b" }}>{credit.vendor}</div>
                    <div style={{ fontSize: "0.8rem", color: "#71717a", marginTop: "2px" }}>{credit.name}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: "1.4rem", fontWeight: 600, color: "#09090b", letterSpacing: "-0.02em" }}>{credit.value}</div>
                    <div style={{ display: "flex", gap: "4px", marginTop: "6px", flexWrap: "wrap", justifyContent: "flex-end" }}>
                      {credit.eligibility.map((e) => (
                        <span key={e} style={{ fontSize: "0.6rem", padding: "2px 8px", borderRadius: "999px", border: "1px solid #e4e4e7", color: "#71717a", letterSpacing: "0.06em" }}>{e}</span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card body */}
                <div style={{ padding: "20px 24px" }}>
                  <p style={{ fontSize: "0.825rem", color: "#71717a", lineHeight: 1.65, marginBottom: "16px" }}>{credit.public_description}</p>

                  {/* Blurred instructions */}
                  <div style={{ position: "relative", borderRadius: "8px", overflow: "hidden" }}>
                    <div style={{ background: "#fafafa", border: "1px solid #e4e4e7", borderRadius: "8px", padding: "14px 16px", filter: "blur(3px)", userSelect: "none", pointerEvents: "none" }}>
                      <p style={{ fontSize: "0.775rem", color: "#71717a", lineHeight: 1.7 }}>{credit.locked_instructions}</p>
                    </div>
                    <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255,255,255,0.7)", backdropFilter: "blur(2px)", borderRadius: "8px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                        <Lock style={{ width: "13px", height: "13px", color: "#71717a" }} />
                        <span style={{ fontSize: "0.775rem", color: "#71717a", fontWeight: 500 }}>Unlock to see instructions</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>

        {/* CTA */}
        <FadeIn delay={0.2}>
          <div style={{ marginTop: "64px", border: "1px solid #e4e4e7", borderRadius: "16px", padding: "48px", background: "#fff", textAlign: "center" }}>
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "16px" }}>One-time $149</p>
            <h2 style={{ fontSize: "clamp(1.4rem, 2.5vw, 2rem)", fontWeight: 600, letterSpacing: "-0.02em", color: "#09090b", marginBottom: "12px" }}>
              Unlock all redemption instructions.
            </h2>
            <p style={{ color: "#71717a", fontSize: "0.875rem", lineHeight: 1.7, maxWidth: "400px", margin: "0 auto 32px auto" }}>
              Get exact codes and step-by-step guides for every credit. Pay once, access forever.
            </p>
            <div className="flex flex-wrap gap-4 justify-center mb-8">
              {["Exact redemption codes", "Step-by-step instructions", "Lifetime updates", "Eligibility checker"].map((perk) => (
                <div key={perk} style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "0.8rem", color: "#71717a" }}>
                  <CheckCircle style={{ width: "12px", height: "12px", color: "#d4d4d8" }} /> {perk}
                </div>
              ))}
            </div>
            <button style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "7px", padding: "12px 28px", fontWeight: 500, cursor: "pointer", fontSize: "0.9rem", display: "inline-flex", alignItems: "center", gap: "8px" }}>
              <Zap style={{ width: "14px", height: "14px" }} />
              Get Lifetime Access — $149
              <ArrowRight style={{ width: "14px", height: "14px" }} />
            </button>
            <p style={{ fontSize: "0.75rem", color: "#a1a1aa", marginTop: "12px" }}>One-time payment · No subscription · Instant access</p>
          </div>
        </FadeIn>

        {/* Footer */}
        <div style={{ borderTop: "1px solid #e4e4e7", marginTop: "64px", paddingTop: "32px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }}>
          <span style={{ color: "#09090b", fontWeight: 600, fontSize: "0.875rem", letterSpacing: "0.12em" }}>FOUNDER OS</span>
          <p style={{ fontSize: "0.75rem", color: "#a1a1aa" }}>Built for founders, by founders.</p>
        </div>
      </div>
    </div>
  );
}