"use client";

import Link from "next/link";
import { ArrowRight, Zap, Lock, CheckCircle } from "lucide-react";
import { motion, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";

function useCountUp(target: number, duration: number = 2000, inView: boolean = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) { setCount(target); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [inView, target, duration]);
  return count;
}

const row1 = [
  { vendor: "Google Cloud", value: "$350,000", category: "Cloud", color: "#4285F4" },
  { vendor: "AWS", value: "$100,000", category: "Cloud", color: "#FF9900" },
  { vendor: "Stripe", value: "$50,000", category: "Finance", color: "#635BFF" },
  { vendor: "Notion", value: "$6,000", category: "Productivity", color: "#000000" },
  { vendor: "Google Cloud", value: "$350,000", category: "Cloud", color: "#4285F4" },
  { vendor: "AWS", value: "$100,000", category: "Cloud", color: "#FF9900" },
  { vendor: "Stripe", value: "$50,000", category: "Finance", color: "#635BFF" },
  { vendor: "Notion", value: "$6,000", category: "Productivity", color: "#000000" },
];
const row2 = [
  { vendor: "Notion", value: "$6,000", category: "Productivity", color: "#000000" },
  { vendor: "Stripe", value: "$50,000", category: "Finance", color: "#635BFF" },
  { vendor: "AWS", value: "$100,000", category: "Cloud", color: "#FF9900" },
  { vendor: "Google Cloud", value: "$350,000", category: "Cloud", color: "#4285F4" },
  { vendor: "Notion", value: "$6,000", category: "Productivity", color: "#000000" },
  { vendor: "Stripe", value: "$50,000", category: "Finance", color: "#635BFF" },
  { vendor: "AWS", value: "$100,000", category: "Cloud", color: "#FF9900" },
  { vendor: "Google Cloud", value: "$350,000", category: "Cloud", color: "#4285F4" },
];

function CreditCard({ vendor, value, category, color }: { vendor: string; value: string; category: string; color: string }) {
  return (
    <div style={{ background: "#fff", border: "1px solid #e4e4e7", borderRadius: "12px", padding: "16px 20px", minWidth: "180px", flexShrink: 0, boxShadow: "0 1px 3px rgba(0,0,0,0.04)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
        <div style={{ width: "28px", height: "28px", borderRadius: "6px", background: color, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ color: "#fff", fontSize: "0.6rem", fontWeight: 700 }}>{vendor[0]}</span>
        </div>
        <span style={{ fontSize: "0.8rem", fontWeight: 500, color: "#09090b" }}>{vendor}</span>
      </div>
      <div style={{ fontSize: "1.1rem", fontWeight: 600, color: "#09090b", letterSpacing: "-0.02em" }}>{value}</div>
      <div style={{ fontSize: "0.65rem", color: "#a1a1aa", marginTop: "4px", textTransform: "uppercase", letterSpacing: "0.08em" }}>{category}</div>
    </div>
  );
}

function TickerRow({ cards, direction }: { cards: typeof row1; direction: "left" | "right" }) {
  return (
    <div style={{ overflow: "hidden", width: "100%" }}>
      <motion.div
        style={{ display: "flex", gap: "12px", width: "max-content" }}
        animate={{ x: direction === "left" ? ["0%", "-50%"] : ["-50%", "0%"] }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      >
        {[...cards, ...cards].map((card, i) => (
          <CreditCard key={i} {...card} />
        ))}
      </motion.div>
    </div>
  );
}

function FadeIn({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}

export default function HomePage() {
  const statsRef = useRef(null);
  const statsInView = useInView(statsRef, { once: true });
  const resources = useCountUp(300, 1800, statsInView);
  const creditsCount = useCountUp(500, 2200, statsInView);

  return (
    <div className="min-h-screen" style={{ background: "#fafafa", color: "#09090b", fontFamily: "Inter, sans-serif" }}>

      {/* Nav */}
      <nav className="sticky top-0 z-50" style={{ borderBottom: "1px solid #e4e4e7", background: "rgba(250,250,250,0.9)", backdropFilter: "blur(12px)" }}>
        <div className="max-w-6xl mx-auto px-8 h-14 flex items-center justify-between">
          <span style={{ color: "#09090b", fontWeight: 600, fontSize: "0.95rem", letterSpacing: "0.12em" }}>FOUNDER OS</span>
          <div className="flex items-center gap-6">
            <Link href="/directory" style={{ color: "#71717a", fontSize: "0.875rem", textDecoration: "none" }}>Directory</Link>
            <Link href="/login" style={{ color: "#71717a", fontSize: "0.875rem", textDecoration: "none" }}>Sign In</Link>
            <Link href="/credits">
              <button style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "6px", padding: "7px 16px", fontWeight: 500, cursor: "pointer", fontSize: "0.875rem" }}>
                Unlock Credits
              </button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-3xl mx-auto px-8 pt-24 pb-16 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "8px", border: "1px solid #e4e4e7", borderRadius: "999px", padding: "5px 14px", marginBottom: "28px", background: "#fff" }}>
            <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#dc2626" }} />
            <span style={{ fontSize: "0.75rem", color: "#71717a", letterSpacing: "0.08em", textTransform: "uppercase" }}>Founder Infrastructure</span>
          </div>
          <h1 style={{ fontSize: "clamp(2.2rem, 5vw, 4rem)", fontWeight: 700, lineHeight: 1.08, marginBottom: "20px", letterSpacing: "-0.03em", color: "#09090b" }}>
            The infrastructure layer<br />for ambitious founders.
          </h1>
          <p style={{ fontSize: "1rem", color: "#71717a", lineHeight: 1.8, maxWidth: "480px", margin: "0 auto 36px auto" }}>
            300+ curated tools, free forever. Plus unlock{" "}
            <span style={{ color: "#09090b", fontWeight: 500 }}>$500,000+ in startup credits</span>{" "}
            from AWS, Google Cloud, and Stripe — for a one-time $149.
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Link href="/directory">
              <button style={{ background: "transparent", border: "1px solid #e4e4e7", color: "#71717a", borderRadius: "7px", padding: "10px 20px", fontWeight: 400, cursor: "pointer", fontSize: "0.875rem" }}>
                Browse Free Directory
              </button>
            </Link>
            <Link href="/credits">
              <button style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "7px", padding: "10px 22px", fontWeight: 500, cursor: "pointer", fontSize: "0.875rem", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                Unlock $500K+ in Credits <ArrowRight style={{ width: "14px", height: "14px" }} />
              </button>
            </Link>
          </div>
        </motion.div>

        {/* Stats */}
        <div ref={statsRef} style={{ display: "flex", border: "1px solid #e4e4e7", borderRadius: "12px", overflow: "hidden", maxWidth: "440px", margin: "52px auto 0 auto", background: "#fff" }}>
          {[
            { label: "Free Resources", value: `${resources}+` },
            { label: "Credit Value", value: `$${creditsCount}K+` },
            { label: "One-time Fee", value: "$149" },
          ].map((stat, i) => (
            <div key={stat.label} style={{ flex: 1, padding: "20px 12px", textAlign: "center", borderRight: i < 2 ? "1px solid #e4e4e7" : "none" }}>
              <div style={{ fontSize: "1.4rem", fontWeight: 600, color: "#09090b", letterSpacing: "-0.02em" }}>{stat.value}</div>
              <div style={{ fontSize: "0.6rem", color: "#a1a1aa", marginTop: "4px", letterSpacing: "0.06em", textTransform: "uppercase" }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Credit Ticker */}
      <div style={{ padding: "24px 0", borderTop: "1px solid #e4e4e7", borderBottom: "1px solid #e4e4e7", background: "#fafafa", display: "flex", flexDirection: "column", gap: "12px", overflow: "hidden" }}>
        <TickerRow cards={row1} direction="left" />
        <TickerRow cards={row2} direction="right" />
      </div>

      {/* Free Tools */}
      <section className="max-w-6xl mx-auto px-8 py-24">
        <FadeIn>
          <div className="max-w-xl mb-14">
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "12px" }}>Free Tier</p>
            <h2 style={{ fontSize: "clamp(1.5rem, 3vw, 2.2rem)", fontWeight: 600, letterSpacing: "-0.02em", color: "#09090b", marginBottom: "10px" }}>Your founder toolkit.</h2>
            <p style={{ color: "#a1a1aa", fontSize: "0.9rem", lineHeight: 1.7 }}>Every tool a founder needs, searchable and filterable. No account required.</p>
          </div>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px" style={{ border: "1px solid #e4e4e7", borderRadius: "12px", overflow: "hidden", background: "#e4e4e7" }}>
          {[
            { title: "Learning & Knowledge", description: "Essays, books, and courses from YC, Paul Graham, and top founders.", count: "50+ resources" },
            { title: "Tools & Software", description: "Design, analytics, automation, CRM, and dev tools for every stage.", count: "200+ tools" },
            { title: "Growth & Marketing", description: "Channels, tactics, and places to share and promote your product.", count: "100+ tactics" },
            { title: "Communities", description: "Indie Hackers, YC alumni networks, and active founder forums.", count: "30+ communities" },
            { title: "Fundraising", description: "Pitch deck examples, angel directories, and fundraising guides.", count: "40+ guides" },
            { title: "Startup Programs", description: "Public listings of AWS, GCP, Stripe, and other startup programs.", count: "60+ programs" },
          ].map((cat, i) => (
            <FadeIn key={cat.title} delay={i * 0.07}>
              <div style={{ background: "#fafafa", padding: "28px 24px", height: "100%" }}>
                <div style={{ fontSize: "0.65rem", color: "#a1a1aa", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: "10px" }}>{cat.count}</div>
                <h3 style={{ fontWeight: 500, marginBottom: "8px", color: "#09090b", fontSize: "0.95rem" }}>{cat.title}</h3>
                <p style={{ fontSize: "0.825rem", color: "#a1a1aa", lineHeight: 1.65 }}>{cat.description}</p>
              </div>
            </FadeIn>
          ))}
        </div>

        <div className="mt-8">
          <Link href="/directory">
            <button style={{ background: "transparent", border: "1px solid #e4e4e7", color: "#71717a", borderRadius: "7px", padding: "9px 18px", cursor: "pointer", fontSize: "0.85rem", display: "inline-flex", alignItems: "center", gap: "6px" }}>
              Browse all resources <ArrowRight style={{ width: "13px", height: "13px" }} />
            </button>
          </Link>
        </div>
      </section>

      {/* Premium CTA */}
      <FadeIn>
        <section className="max-w-6xl mx-auto px-8 pb-28" style={{ borderTop: "1px solid #e4e4e7", paddingTop: "96px" }}>
          <div style={{ border: "1px solid #e4e4e7", borderRadius: "16px", padding: "56px 64px", background: "#fff" }}>
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "20px" }}>Premium · One-time $149</p>
            <h2 style={{ fontSize: "clamp(1.5rem, 3vw, 2.4rem)", fontWeight: 600, letterSpacing: "-0.02em", color: "#09090b", marginBottom: "14px" }}>
              Unlock $500K+ in startup credits.
            </h2>
            <p style={{ color: "#71717a", marginBottom: "40px", maxWidth: "480px", lineHeight: 1.7, fontSize: "0.9rem" }}>
              Exact redemption codes and step-by-step instructions for AWS, Google Cloud, Stripe, and Notion. Pay once, access forever.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
              {[
                { vendor: "Google Cloud", value: "$350,000" },
                { vendor: "AWS Activate", value: "$100,000" },
                { vendor: "Stripe", value: "$50,000" },
                { vendor: "Notion", value: "$6,000" },
              ].map((credit) => (
                <div key={credit.vendor} style={{ background: "#fafafa", border: "1px solid #e4e4e7", borderRadius: "10px", padding: "16px 18px" }}>
                  <Lock style={{ width: "11px", height: "11px", color: "#d4d4d8", marginBottom: "10px" }} />
                  <div style={{ fontSize: "1.2rem", fontWeight: 600, color: "#09090b", letterSpacing: "-0.02em" }}>{credit.value}</div>
                  <div style={{ fontSize: "0.75rem", color: "#a1a1aa", marginTop: "4px" }}>{credit.vendor}</div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-5 mb-10">
              {["Exact redemption codes", "Step-by-step instructions", "Eligibility checker", "Lifetime updates"].map((perk) => (
                <div key={perk} style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.825rem", color: "#71717a" }}>
                  <CheckCircle style={{ width: "13px", height: "13px", color: "#d4d4d8" }} /> {perk}
                </div>
              ))}
            </div>

            <Link href="/credits">
              <button style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "7px", padding: "12px 28px", fontWeight: 500, cursor: "pointer", fontSize: "0.9rem", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                <Zap style={{ width: "14px", height: "14px" }} />
                Get Lifetime Access — $149
                <ArrowRight style={{ width: "14px", height: "14px" }} />
              </button>
            </Link>
            <p style={{ fontSize: "0.75rem", color: "#a1a1aa", marginTop: "14px" }}>One-time payment · No subscription · Instant access</p>
          </div>
        </section>
      </FadeIn>

      {/* Footer */}
      <footer style={{ borderTop: "1px solid #e4e4e7", padding: "32px 0" }}>
        <div className="max-w-6xl mx-auto px-8 flex items-center justify-between flex-wrap gap-4">
          <span style={{ color: "#09090b", fontWeight: 600, fontSize: "0.875rem", letterSpacing: "0.12em" }}>FOUNDER OS</span>
          <p style={{ fontSize: "0.75rem", color: "#a1a1aa" }}>Built for founders, by founders.</p>
        </div>
      </footer>

    </div>
  );
}