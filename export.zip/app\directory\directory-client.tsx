"use client";

import { useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Search, ExternalLink, ArrowRight } from "lucide-react";
import Link from "next/link";

type Resource = { title: string; url: string; category: string };

function FadeIn({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}} transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}>
      {children}
    </motion.div>
  );
}

export default function DirectoryClient({ resources, categories }: { resources: Resource[]; categories: string[] }) {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const [showSuggest, setShowSuggest] = useState(false);

 const filtered = resources.filter((r) => {
    const matchSearch = (r.title ?? "").toLowerCase().includes(search.toLowerCase()) || (r.url ?? "").toLowerCase().includes(search.toLowerCase());
    const matchCat = activeCategory === "All" || r.category === activeCategory;
    return matchSearch && matchCat;
  });

  return (
    <div style={{ background: "#fafafa", minHeight: "100vh", fontFamily: "Inter, sans-serif" }}>

      {/* Nav */}
      <nav className="sticky top-0 z-50" style={{ borderBottom: "1px solid #e4e4e7", background: "rgba(250,250,250,0.9)", backdropFilter: "blur(12px)" }}>
        <div className="max-w-6xl mx-auto px-8 h-14 flex items-center justify-between">
          <Link href="/" style={{ textDecoration: "none" }}>
            <span style={{ color: "#09090b", fontWeight: 600, fontSize: "0.95rem", letterSpacing: "0.12em" }}>FOUNDER OS</span>
          </Link>
          <div className="flex items-center gap-6">
            <span style={{ color: "#09090b", fontSize: "0.875rem", fontWeight: 500 }}>Directory</span>
            <Link href="/credits">
              <button style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "6px", padding: "7px 16px", fontWeight: 500, cursor: "pointer", fontSize: "0.875rem" }}>
                Unlock Credits
              </button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Header */}
      <div style={{ borderBottom: "1px solid #e4e4e7", background: "#fff", padding: "48px 0 36px" }}>
        <div className="max-w-6xl mx-auto px-8">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}>
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "10px" }}>Free Tier</p>
            <h1 style={{ fontSize: "clamp(1.6rem, 3vw, 2.4rem)", fontWeight: 600, letterSpacing: "-0.02em", color: "#09090b", marginBottom: "8px" }}>
              Founder Toolkit
            </h1>
            <p style={{ color: "#a1a1aa", fontSize: "0.9rem", marginBottom: "28px" }}>
              {resources.length} resources across {categories.length} categories. No account required.
            </p>

            {/* Search */}
            <div style={{ position: "relative", maxWidth: "480px" }}>
              <Search style={{ position: "absolute", left: "14px", top: "50%", transform: "translateY(-50%)", width: "15px", height: "15px", color: "#a1a1aa" }} />
              <input
                type="text"
                placeholder="Search tools, resources..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                style={{ width: "100%", paddingLeft: "40px", paddingRight: "16px", paddingTop: "10px", paddingBottom: "10px", border: "1px solid #e4e4e7", borderRadius: "8px", fontSize: "0.875rem", background: "#fafafa", color: "#09090b", outline: "none", boxSizing: "border-box" }}
              />
            </div>
          </motion.div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-8 py-8">
        {/* Category filters */}
        <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "32px" }}>
         {["All", ...categories.filter(c => c !== "All")].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              style={{
                padding: "6px 14px", borderRadius: "999px", fontSize: "0.775rem", cursor: "pointer", fontWeight: 400, border: "1px solid",
                borderColor: activeCategory === cat ? "#09090b" : "#e4e4e7",
                background: activeCategory === cat ? "#09090b" : "#fff",
                color: activeCategory === cat ? "#fff" : "#71717a",
              }}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results count */}
        <div style={{ marginBottom: "20px", fontSize: "0.8rem", color: "#a1a1aa" }}>
          {filtered.length} results {search && `for "${search}"`}
        </div>

        {/* Resource grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((resource, i) => (
            <FadeIn key={resource.url + i} delay={Math.min(i * 0.03, 0.3)}>
              <a href={resource.url} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
                <div style={{ background: "#fff", border: "1px solid #e4e4e7", borderRadius: "10px", padding: "16px 18px", cursor: "pointer", transition: "border-color 0.15s" }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = "#a1a1aa")}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = "#e4e4e7")}
                >
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px" }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: "0.65rem", color: "#a1a1aa", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: "6px" }}>{resource.category}</div>
                      <div style={{ fontSize: "0.875rem", fontWeight: 500, color: "#09090b", lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{resource.title}</div>
                      <div style={{ fontSize: "0.75rem", color: "#a1a1aa", marginTop: "4px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{resource.url.replace(/^https?:\/\//, "")}</div>
                    </div>
                    <ExternalLink style={{ width: "13px", height: "13px", color: "#d4d4d8", flexShrink: 0, marginTop: "2px" }} />
                  </div>
                </div>
              </a>
            </FadeIn>
          ))}
        </div>

        {/* Suggest + Premium CTA */}
        <div style={{ marginTop: "64px", borderTop: "1px solid #e4e4e7", paddingTop: "48px", display: "flex", gap: "16px", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <p style={{ fontSize: "0.875rem", color: "#09090b", fontWeight: 500, marginBottom: "4px" }}>Missing a tool?</p>
            <p style={{ fontSize: "0.8rem", color: "#a1a1aa" }}>Suggest a resource to be added to the directory.</p>
          </div>
          <div style={{ display: "flex", gap: "10px" }}>
            <button onClick={() => setShowSuggest(true)} style={{ background: "transparent", border: "1px solid #e4e4e7", color: "#71717a", borderRadius: "7px", padding: "9px 18px", cursor: "pointer", fontSize: "0.85rem" }}>
              Suggest a Tool
            </button>
            <Link href="/credits">
              <button style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "7px", padding: "9px 18px", fontWeight: 500, cursor: "pointer", fontSize: "0.85rem", display: "inline-flex", alignItems: "center", gap: "6px" }}>
                Unlock Credits <ArrowRight style={{ width: "13px", height: "13px" }} />
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Suggest Modal */}
      {showSuggest && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.3)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: "24px" }} onClick={() => setShowSuggest(false)}>
          <div style={{ background: "#fff", borderRadius: "14px", padding: "32px", maxWidth: "420px", width: "100%" }} onClick={e => e.stopPropagation()}>
            <h3 style={{ fontWeight: 600, fontSize: "1.1rem", marginBottom: "6px", color: "#09090b" }}>Suggest a Tool</h3>
            <p style={{ fontSize: "0.825rem", color: "#a1a1aa", marginBottom: "20px" }}>Know a great resource for founders? Share it below.</p>
            <input placeholder="Tool name" style={{ width: "100%", padding: "10px 14px", border: "1px solid #e4e4e7", borderRadius: "7px", fontSize: "0.875rem", marginBottom: "10px", boxSizing: "border-box", outline: "none" }} />
            <input placeholder="URL (https://...)" style={{ width: "100%", padding: "10px 14px", border: "1px solid #e4e4e7", borderRadius: "7px", fontSize: "0.875rem", marginBottom: "16px", boxSizing: "border-box", outline: "none" }} />
            <div style={{ display: "flex", gap: "8px", justifyContent: "flex-end" }}>
              <button onClick={() => setShowSuggest(false)} style={{ padding: "9px 18px", border: "1px solid #e4e4e7", borderRadius: "7px", background: "transparent", color: "#71717a", cursor: "pointer", fontSize: "0.85rem" }}>Cancel</button>
              <button onClick={() => setShowSuggest(false)} style={{ padding: "9px 18px", border: "none", borderRadius: "7px", background: "#dc2626", color: "#fff", cursor: "pointer", fontSize: "0.85rem", fontWeight: 500 }}>Submit</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}