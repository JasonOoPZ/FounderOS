"use client";

import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Lock, CheckCircle, LogOut, Zap, ArrowRight, Cloud, CreditCard, BookOpen, Clock, ExternalLink, ChevronRight } from "lucide-react";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

const credits = [
  {
    vendor: "AWS",
    name: "AWS Activate Founders",
    value: "$100,000",
    category: "Cloud",
    color: "#FF9900",
    eligibility: ["Funded", "Accelerator"],
    approval_time: "3–5 business days",
    apply_url: "https://aws.amazon.com/activate",
    public_description: "Up to $100K in AWS Promotional Credit for AI/ML and Web3 startups.",
    locked_instructions: "1. Go to aws.amazon.com/activate.\n2. Apply for the Portfolio tier.\n3. Use our partner Org ID: FUSH-AWS-2026.\n4. Ensure your cap table reflects your recent funding.",
  },
  {
    vendor: "Notion",
    name: "Notion for Startups",
    value: "$6,000",
    category: "Productivity",
    color: "#000000",
    eligibility: ["Bootstrapped", "Funded", "Accelerator"],
    approval_time: "1–2 business days",
    apply_url: "https://notion.so/startups",
    public_description: "Up to 6 months free of Notion Plus, including unlimited AI.",
    locked_instructions: "1. Go to notion.so/startups.\n2. Click 'Apply Now'.\n3. Select 'Partner' in the dropdown.\n4. Enter partner code: FUSH-NOTION-2026.",
  },
  {
    vendor: "Google Cloud",
    name: "GCP Startups Scale Tier",
    value: "$350,000",
    category: "Cloud",
    color: "#4285F4",
    eligibility: ["Funded", "Accelerator"],
    approval_time: "5–7 business days",
    apply_url: "https://cloud.google.com/startup",
    public_description: "Up to $350K USD in Google Cloud credits for scaling startups.",
    locked_instructions: "1. Visit cloud.google.com/startup.\n2. Apply for the 'Scale Tier'.\n3. Upload your Seed/Series A term sheet or accelerator acceptance letter.",
  },
  {
    vendor: "Stripe",
    name: "Stripe Fee Waiver",
    value: "$50,000",
    category: "Finance",
    color: "#635BFF",
    eligibility: ["Bootstrapped", "Funded", "Accelerator"],
    approval_time: "Instant",
    apply_url: "https://stripe.com",
    public_description: "$50,000 in fee-free processing to help you get off the ground.",
    locked_instructions: "1. Create a Stripe account.\n2. Go to Settings > Business settings > Programs.\n3. Enter the waiver code: STRIPE-FUSH-50K.",
  },
];

const navItems = [
  { label: "Credits", icon: CreditCard, id: "credits" },
  { label: "Directory", icon: BookOpen, id: "directory", href: "/directory" },
];

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [isPro, setIsPro] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("credits");
  const [activeCredit, setActiveCredit] = useState(credits[0]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) { router.push("/login"); return; }
      setUser(session.user);
      supabase.from("users").select("is_pro").eq("id", session.user.id).single()
        .then(({ data, error }) => {
          console.log("user data:", data, "error:", error);
          setIsPro(data?.is_pro ?? false);
          setLoading(false);
        });
    });
  }, []);

  async function handleSignOut() {
    await supabase.auth.signOut();
    router.push("/");
  }

  async function handleCheckout() {
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: user?.email }),
    });
    const { url } = await res.json();
    if (url) window.location.href = url;
  }

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#fafafa" }}>
      <p style={{ color: "#a1a1aa", fontSize: "0.875rem" }}>Loading...</p>
    </div>
  );

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#fafafa", fontFamily: "Inter, sans-serif" }}>

      {/* Sidebar */}
      <aside style={{ width: "220px", borderRight: "1px solid #e4e4e7", background: "#fff", display: "flex", flexDirection: "column", position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 40 }}>
        <div style={{ padding: "20px 20px 16px", borderBottom: "1px solid #e4e4e7" }}>
          <Link href="/" style={{ textDecoration: "none" }}>
            <span style={{ fontWeight: 600, fontSize: "0.9rem", letterSpacing: "0.12em", color: "#09090b" }}>FOUNDER OS</span>
          </Link>
          {isPro && (
            <div style={{ marginTop: "8px", display: "inline-flex", alignItems: "center", gap: "5px", background: "#09090b", borderRadius: "999px", padding: "3px 10px" }}>
              <div style={{ width: "5px", height: "5px", borderRadius: "50%", background: "#4ade80" }} />
              <span style={{ fontSize: "0.6rem", color: "#fff", letterSpacing: "0.08em" }}>PRO ACCESS</span>
            </div>
          )}
        </div>

        <nav style={{ padding: "12px 12px", flex: 1 }}>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return item.href ? (
              <Link key={item.id} href={item.href} style={{ textDecoration: "none" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "9px 12px", borderRadius: "7px", marginBottom: "2px", background: "transparent", cursor: "pointer", color: "#71717a", fontSize: "0.85rem" }}>
                  <Icon style={{ width: "15px", height: "15px" }} />
                  {item.label}
                </div>
              </Link>
            ) : (
              <div key={item.id} onClick={() => setActiveTab(item.id)}
                style={{ display: "flex", alignItems: "center", gap: "10px", padding: "9px 12px", borderRadius: "7px", marginBottom: "2px", background: isActive ? "#fafafa" : "transparent", border: isActive ? "1px solid #e4e4e7" : "1px solid transparent", cursor: "pointer", color: isActive ? "#09090b" : "#71717a", fontSize: "0.85rem", fontWeight: isActive ? 500 : 400 }}>
                <Icon style={{ width: "15px", height: "15px" }} />
                {item.label}
              </div>
            );
          })}
        </nav>

        <div style={{ padding: "16px", borderTop: "1px solid #e4e4e7" }}>
          <div style={{ fontSize: "0.75rem", color: "#a1a1aa", marginBottom: "8px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user?.email}</div>
          <button onClick={handleSignOut} style={{ display: "flex", alignItems: "center", gap: "6px", background: "none", border: "none", cursor: "pointer", color: "#a1a1aa", fontSize: "0.8rem", padding: 0 }}>
            <LogOut style={{ width: "13px", height: "13px" }} /> Sign out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ marginLeft: "220px", flex: 1, padding: "40px 48px" }}>

        {/* Paywall state */}
        {!isPro ? (
          <div>
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "8px" }}>Dashboard</p>
            <h1 style={{ fontSize: "1.8rem", fontWeight: 600, color: "#09090b", marginBottom: "8px" }}>Unlock Your Credits</h1>
            <p style={{ color: "#a1a1aa", fontSize: "0.875rem", marginBottom: "32px" }}>Purchase lifetime access to see exact instructions for all credits.</p>

            <div style={{ background: "#fff", border: "1px solid #e4e4e7", borderRadius: "12px", padding: "28px 32px", marginBottom: "32px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "16px" }}>
              <div>
                <p style={{ fontWeight: 500, color: "#09090b", marginBottom: "4px" }}>Get lifetime access for $149</p>
                <p style={{ fontSize: "0.825rem", color: "#a1a1aa" }}>One-time payment. Unlock all credit instructions instantly.</p>
              </div>
              <button onClick={handleCheckout} style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "7px", padding: "10px 22px", fontWeight: 500, cursor: "pointer", fontSize: "0.875rem", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                <Zap style={{ width: "13px", height: "13px" }} /> Unlock Now — $149 <ArrowRight style={{ width: "13px", height: "13px" }} />
              </button>
            </div>

            {/* Locked preview cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {credits.map((credit) => (
                <div key={credit.vendor} style={{ background: "#fff", border: "1px solid #e4e4e7", borderRadius: "12px", overflow: "hidden" }}>
                  <div style={{ padding: "20px 24px", borderBottom: "1px solid #e4e4e7", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                      <div style={{ width: "36px", height: "36px", borderRadius: "8px", background: credit.color, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <span style={{ color: "#fff", fontWeight: 700, fontSize: "0.75rem" }}>{credit.vendor[0]}</span>
                      </div>
                      <div>
                        <div style={{ fontSize: "0.95rem", fontWeight: 600, color: "#09090b" }}>{credit.vendor}</div>
                        <div style={{ fontSize: "0.75rem", color: "#71717a" }}>{credit.name}</div>
                      </div>
                    </div>
                    <div style={{ fontSize: "1.3rem", fontWeight: 600, color: "#09090b" }}>{credit.value}</div>
                  </div>
                  <div style={{ padding: "16px 24px", position: "relative" }}>
                    <div style={{ filter: "blur(4px)", userSelect: "none", pointerEvents: "none" }}>
                      <p style={{ fontSize: "0.8rem", color: "#71717a", lineHeight: 1.7 }}>{credit.locked_instructions}</p>
                    </div>
                    <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "6px", background: "#fff", border: "1px solid #e4e4e7", borderRadius: "999px", padding: "6px 14px" }}>
                        <Lock style={{ width: "11px", height: "11px", color: "#a1a1aa" }} />
                        <span style={{ fontSize: "0.75rem", color: "#71717a" }}>Unlock to see instructions</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        ) : (
          // PRO state — split panel
          <div>
            <p style={{ fontSize: "0.7rem", color: "#a1a1aa", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: "8px" }}>Credits</p>
            <h1 style={{ fontSize: "1.8rem", fontWeight: 600, color: "#09090b", marginBottom: "28px" }}>Your Startup Credits</h1>

            <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: "20px", alignItems: "start" }}>

              {/* Credit list */}
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {credits.map((credit) => (
                  <div key={credit.vendor} onClick={() => setActiveCredit(credit)}
                    style={{ background: activeCredit.vendor === credit.vendor ? "#fafafa" : "#fff", border: `1px solid ${activeCredit.vendor === credit.vendor ? "#09090b" : "#e4e4e7"}`, borderRadius: "10px", padding: "14px 16px", cursor: "pointer", transition: "all 0.15s" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <div style={{ width: "30px", height: "30px", borderRadius: "7px", background: credit.color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                          <span style={{ color: "#fff", fontWeight: 700, fontSize: "0.7rem" }}>{credit.vendor[0]}</span>
                        </div>
                        <div>
                          <div style={{ fontSize: "0.85rem", fontWeight: 500, color: "#09090b" }}>{credit.vendor}</div>
                          <div style={{ fontSize: "0.7rem", color: "#a1a1aa" }}>{credit.value}</div>
                        </div>
                      </div>
                      <ChevronRight style={{ width: "14px", height: "14px", color: "#a1a1aa" }} />
                    </div>
                  </div>
                ))}
              </div>

              {/* Credit detail panel */}
              <div style={{ background: "#fff", border: "1px solid #e4e4e7", borderRadius: "14px", overflow: "hidden" }}>

                {/* Header */}
                <div style={{ padding: "28px 32px", borderBottom: "1px solid #e4e4e7", background: "#fafafa" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "14px", marginBottom: "16px" }}>
                    <div style={{ width: "44px", height: "44px", borderRadius: "10px", background: activeCredit.color, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <span style={{ color: "#fff", fontWeight: 700, fontSize: "0.9rem" }}>{activeCredit.vendor[0]}</span>
                    </div>
                    <div>
                      <div style={{ fontSize: "1.1rem", fontWeight: 600, color: "#09090b" }}>{activeCredit.vendor}</div>
                      <div style={{ fontSize: "0.8rem", color: "#71717a" }}>{activeCredit.name}</div>
                    </div>
                    <div style={{ marginLeft: "auto", fontSize: "1.8rem", fontWeight: 700, color: "#09090b", letterSpacing: "-0.03em" }}>{activeCredit.value}</div>
                  </div>

                  <div style={{ display: "flex", gap: "24px", flexWrap: "wrap" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                      <Clock style={{ width: "12px", height: "12px", color: "#a1a1aa" }} />
                      <span style={{ fontSize: "0.75rem", color: "#71717a" }}>Approval: {activeCredit.approval_time}</span>
                    </div>
                    <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                      {activeCredit.eligibility.map(e => (
                        <span key={e} style={{ fontSize: "0.65rem", padding: "2px 9px", borderRadius: "999px", border: "1px solid #e4e4e7", color: "#71717a", background: "#fff" }}>{e}</span>
                      ))}
                    </div>
                  </div>
                </div>

                <div style={{ padding: "28px 32px" }}>

                  {/* Description */}
                  <p style={{ fontSize: "0.875rem", color: "#71717a", lineHeight: 1.7, marginBottom: "28px" }}>{activeCredit.public_description}</p>

                  {/* Instructions */}
                  <div style={{ marginBottom: "28px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "14px" }}>
                      <CheckCircle style={{ width: "14px", height: "14px", color: "#16a34a" }} />
                      <span style={{ fontSize: "0.8rem", fontWeight: 600, color: "#09090b" }}>Step-by-step instructions</span>
                    </div>
                    <div style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: "10px", padding: "20px 22px" }}>
                      {activeCredit.locked_instructions.split("\n").map((step, i) => (
                        <div key={i} style={{ display: "flex", gap: "12px", marginBottom: i < activeCredit.locked_instructions.split("\n").length - 1 ? "12px" : "0" }}>
                          <div style={{ width: "20px", height: "20px", borderRadius: "50%", background: "#16a34a", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: "1px" }}>
                            <span style={{ fontSize: "0.6rem", color: "#fff", fontWeight: 700 }}>{i + 1}</span>
                          </div>
                          <p style={{ fontSize: "0.825rem", color: "#166534", lineHeight: 1.65 }}>{step.replace(/^\d+\.\s/, "")}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Apply button */}
                  <a href={activeCredit.apply_url} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
                    <button style={{ background: "#09090b", color: "#fff", border: "none", borderRadius: "8px", padding: "11px 24px", fontWeight: 500, cursor: "pointer", fontSize: "0.875rem", display: "inline-flex", alignItems: "center", gap: "8px" }}>
                      Apply Now <ExternalLink style={{ width: "13px", height: "13px" }} />
                    </button>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}